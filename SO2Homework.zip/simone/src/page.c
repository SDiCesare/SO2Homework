#include"page.h"
#include<string.h>

Page* createPage(int width, int height, int sectionCount, int sectionDistance) {
	Page* page = (Page*)malloc(sizeof(Page));
	page->width = width;
	page->height = height;
	page->sectionCount = sectionCount;
	page->sectionDistance = sectionDistance;
	page->lines = (char**)malloc(sizeof(char*)*height);
	for (int i = 0; i < height; i++) {
		page->lines[i] = (char*)malloc((sizeof(char)*(width + sectionDistance)*sectionCount) - sizeof(char)*sectionDistance);
	}
	return page;
}
