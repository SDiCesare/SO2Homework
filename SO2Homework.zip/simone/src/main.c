#include<stdio.h>
#include<string.h>
#include"page.h"

void fillSections(Page* page) {
	for (int i = 0; i < page->height; i++) {
		for (int j = 0; j < page->sectionCount; j++) {
			for (int k = 0; k < page->width; k++) {
				int index = (j * (page->width + page->sectionDistance)) + k;
				page->lines[i][index] = 'c';
			}
			if (j == page->sectionCount - 1) {
				continue;
			}
			for (int k = 0; k < page->sectionDistance; k++) {
				int index = (j * (page->width + page->sectionDistance) + page->width) + k;
				page->lines[i][index] = 'k';
			}
		}
	}
}

int main(int argc, char* argv[]) {
	Page* page = createPage(10, 3, 10, 2);
	fillSections(page);
	for (int i = 0; i < page->height; i++) {
		printf("%s\n", page->lines[i]);
	}
	return 0;
}
