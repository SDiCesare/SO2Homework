#ifndef PAGE_H
#define PAGE_H

typedef struct {
	int width;
	int height;
	int sectionCount;
	int sectionDistance;
	char **lines;
} Page;

Page* createPage(int width, int height, int sectionCount, int sectionDistance);

#endif
